# Transcription Indicator

A lightweight macOS overlay that provides a visual status indicator for recording workflows. The indicator is delivered as a signed Swift app with a Unix-domain socket control channel and can be orchestrated from Python, shell scripts, or other native clients.

## Highlights

- **Dynamic overlay**: Circular, square, or triangular indicator rendered with configurable colour, size, and breathing animation.
- **Loudness-aware glow**: Normalised audio levels tween the glow intensity with 100 ms smoothing and immediate cancellations when new levels arrive.
- **Robust IPC**: POSIX Unix-domain socket (`$TMPDIR/transcription-indicator.sock`) plus optional stdin commands for backwards compatibility.
- **Single instance manager**: Safely serialises commands from secondary launches and rejects duplicate processes.
- **Script-friendly automation**: Works smoothly with Python or shell clients via Unix sockets or stdin piping.
- **Signed release artifacts**: `release/TranscriptionIndicator` and `release/TranscriptionIndicator.app` are ready for redistribution or further signing.

## Repository Layout

```
.
├── Package.swift              # Swift package manifest
├── Resources/                 # Colour definitions, nibs, assets
├── Scripts/
│   └── build.sh               # Release build script (creates bundles in ./release)
├── Sources/
│   ├── Communication/         # Command parsing & socket bridge
│   ├── Core/                  # Models, errors, single-instance manager
│   └── TranscriptionIndicator # AppDelegate + App entry point
├── Tests/                     # Swift unit tests
└── release/                  # Latest signed build artifacts
```

> **Signed build:** The current handoff includes a freshly built and ad-hoc signed bundle. Paths:
>
> - Executable: `release/TranscriptionIndicator`
> - App bundle: `release/TranscriptionIndicator.app`

## Building

Requirements:

- macOS 12+
- Xcode command line tools (Swift 5.9+)

```bash
# Build and stage the release artifacts
Scripts/build.sh
```

The script performs a clean build, places products in `release/`, and prints signing guidance. If you need a clean slate first, run `git status` to confirm the working tree is empty.

### Code signing

The shipping bundle in `release/TranscriptionIndicator.app` is ad-hoc signed so it runs locally (and via subprocess). For distribution outside the current machine, re-sign with your Developer ID certificate and notarise if required:

```bash
codesign --deep --force --verify --verbose \
  --sign "Developer ID Application: <Your Name>" \
  release/TranscriptionIndicator.app
```

## Running the Indicator

### CLI / Shell

1. Launch the indicator once:
   ```bash
   ./release/TranscriptionIndicator --debug
   ```
2. Send commands through stdin:
   ```bash
   echo "show 45" | ./release/TranscriptionIndicator
   ```

The first invocation acquires the single-instance lock and starts the socket server. Subsequent invocations detect the running instance and forward `stdin` or CLI arguments to it.

### Python client workflow

The preferred integration pattern keeps a helper process alive and streams commands through the socket:

```python
import socket
import os

SOCKET_PATH = os.path.join(os.getenv("TMPDIR"), "transcription-indicator.sock")

with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
    client.connect(SOCKET_PATH)
    client.sendall(b"show 30\n")
    print(client.recv(4096).decode())
    client.sendall(b"loudness 0.6\n")
```

If you rely on the legacy stdin bridge, launch the helper via `subprocess.Popen` and write commands to its stdin pipe. A heartbeat (`keepalive`) every ~10 seconds prevents auto-hide when recording is active.

### Socket command reference

Each line sent over the socket or stdin corresponds to a command:

| Command | Arguments | Description |
| ------- | --------- | ----------- |
| `show [seconds]` | optional float | Show indicator and start countdown (default 30 s). |
| `hide` | – | Hide and reset countdown. |
| `shape <circle|square|triangle>` | enum | Change rendered shape. |
| `color <name|#RRGGBB>` | string | Apply named or hex colour. |
| `size <10-200>` | int | Adjust base indicator size in pixels. |
| `animate <on|off>` | flag | Toggle breathing animation. |
| `speed <0.1-10.0>` | seconds | Control full animation cycle length. |
| `span <0.0-1.0>` | float | Set scale factor for breathing. |
| `loudness <0.0-1.0>` | float | Drive glow intensity with tweening. |
| `countdown <seconds>` | float | Override auto-hide countdown. |
| `keepalive` | – | Refresh countdown to avoid auto-hide. |

Responses are newline-delimited status strings. A typical success reply is `OK: Color set to red`. Errors return `ERROR: …` explanations.

## Application Architecture

- **AppDelegate / App.swift**: Bootstraps AppKit, configures single-instance guard, and wires the command processor to stdin and socket handlers.
- **SimpleCommandProcessor**: Parses incoming commands, mutates indicator state, and orchestrates animations/timers.
- **UnixCommandServer & Client**: POSIX socket listener that accepts newline-delimited commands. Secondary launches reuse `UnixCommandClient` to forward instructions when the lock is held.
- **SimpleStdinHandler**: Legacy bridge for shell piping; still active when using `echo "command" | release/TranscriptionIndicator`.
- **SingleInstanceManager**: File-lock backed coordination layer to ensure only one UI instance operates at a time; routes arguments from second launches back to the primary process.

## Troubleshooting

- **Socket already in use**: Remove the stale file in `$TMPDIR/transcription-indicator.sock` and relaunch.
- **Broken pipe warnings**: The client wrote to the socket after the indicator exited; reconnect to a new process.
- **Gatekeeper prompt**: Re-sign with a trusted certificate or right-click → Open the `.app` once to whitelist it.
- **Swift concurrency warnings**: Known lint from Swift 5.9 regarding `Sendable`; harmless on current toolchain but flagging future Swift 6 work.

## Next Steps

- Validate automated demos that exercise `show`, `shape`, `color`, `size`, `animate`, and `loudness` to ensure UI stability after launch.
- Add integration tests around socket reconnects and loudness tween cancellation for additional safety.
- Extend docs with a full socket API examples page if new commands are introduced.

---

Maintained by the recording tools team. Contributions welcome via pull requests.
